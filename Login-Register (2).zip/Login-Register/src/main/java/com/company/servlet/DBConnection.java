package com.company.servlet;


	import java.sql.Connection;
	import java.sql.DriverManager;
	import java.sql.SQLException;

	public class DBConnection {
	    private static final String URL = "jdbc:mysql://localhost:3306/careerguidance";
	    private static final String USER = "root";
	    private static final String PASSWORD = "mysql";
	    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";

	    public static Connection getConnection() {
	        try {
	            Class.forName(DRIVER);
	            return DriverManager.getConnection(URL, USER, PASSWORD);
	        } catch (ClassNotFoundException | SQLException e) {
	            throw new RuntimeException("Error connecting to the database", e);
	        }
	    }
	}



