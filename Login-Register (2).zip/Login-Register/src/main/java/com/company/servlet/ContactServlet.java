package com.company.servlet;

import java.io.IOException;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import jakarta.servlet.ServletException;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

@WebServlet(name = "ContactServlet", urlPatterns = {"/contac"})
public class ContactServlet extends HttpServlet {

    private static final String URL = "jdbc:mysql://localhost:3306/careerguidance";
    private static final String USER = "root";
    private static final String PASSWORD = "mysql";
    private static final String DRIVER = "com.mysql.cj.jdbc.Driver";

    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String firstname = request.getParameter("firstname");
        String lastname = request.getParameter("lastname");
        String email = request.getParameter("email");
       String msg = request.getParameter("msg");
       

        if (ContactServlet(firstname, lastname, email, msg)) {
            response.sendRedirect("/Login-Register/index.html"); // Redirect to registration success page
            System.out.print("ok");
        } else {
            request.setAttribute("errorMessage", "Registration failed. Please try again.");
            request.getRequestDispatcher("/Login-Register/index.html").forward(request, response);
            System.out.print("nooo");
        }
    }

    

    private boolean ContactServlet(String firstname, String lastname, String email, String msg) {
        String sql = "INSERT INTO contact (firstname, lastname, email, msg) VALUES (?, ?, ?, ?)";
        try {
            Class.forName(DRIVER);
            try (Connection conn = DriverManager.getConnection(URL, USER, PASSWORD);
                 PreparedStatement stmt = conn.prepareStatement(sql)) {
                stmt.setString(1, firstname);
                stmt.setString(2, lastname);
                stmt.setString(3, email);
                stmt.setString(4, msg);
                int rowsInserted = stmt.executeUpdate();
                return rowsInserted > 0;
            }
        } catch (ClassNotFoundException | SQLException e) {
            e.printStackTrace();
            return false;
        }
    }
}
