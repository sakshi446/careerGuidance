package com.company.servlet;
import java.io.*;
import java.sql.*;

import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServlet;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;

public class ContactServlet extends HttpServlet {
    public void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        // JDBC code to retrieve data from the database
        Connection conn = null;
        Statement stmt = null;
        ResultSet rs = null;

        try {
            // Establishing a connection
            conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/careerguidance", "root", "mysql");
            stmt = conn.createStatement();

            // Executing the query
            String query = "SELECT * FROM contact";
            rs = stmt.executeQuery(query);

            // Formatting the data for display on the admin page
            StringBuilder html = new StringBuilder();
            html.append("<table border=\"1\">");
            html.append("<tr><th>First Name</th><th>Last Name</th><th>Mobile</th><th>Email</th><th>Message</th></tr>");
            while (rs.next()) {
                html.append("<tr>");
                html.append("<td>").append(rs.getString("firstname")).append("</td>");
                html.append("<td>").append(rs.getString("lastname")).append("</td>");
                html.append("<td>").append(rs.getString("mobno")).append("</td>");
                html.append("<td>").append(rs.getString("email")).append("</td>");
                html.append("<td>").append(rs.getString("msg")).append("</td>");
                html.append("</tr>");
            }
            html.append("</table>");

            // Sending the formatted data to the admin page
            PrintWriter out = response.getWriter();
            out.println(html.toString());
        } catch (SQLException e) {
            // Handle any errors
            e.printStackTrace();
        } finally {
            // Closing resources
            try {
                if (rs != null) rs.close();
                if (stmt != null) stmt.close();
                if (conn != null) conn.close();
            } catch (SQLException e) {
                e.printStackTrace();
            }
        }
    }
}